const { getObjectFromS3, putObjectToS3 } = require("./s3.js");

exports.handler = async (event) => {
  try {
    let putObjt = await putObjectToS3(process.env.BUCKET, 'test', 'test');
    let debObjt = await getObjectFromS3(process.env.BUCKET, 'helloworld.json')
    let response = {
      statusCode: 200,
      body: {
        "putobjt":putObjt,
        "body": debObjt
      }
    };
    return response;
  } catch(err) {
    console.error(err)
    let response = {
      statusCode: 500,
      body: JSON.stringify(err),
    };
    return response
  };
};
