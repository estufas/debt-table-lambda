var AWS = require('aws-sdk');
async function putObjectToS3(bucket, key, data){
  var s3 = new AWS.S3();
  const objectName = 'helloworld.json'; // File name which you want to put in s3 bucket
  const objectData = '{ "message" : "Hello World!" }'; // file data you want to put
  const objectType = 'application/json'; // type of file
  try {
    // setup params for putObject
    const params = {
      Bucket: bucket,
      Key: objectName,
      Body: objectData,
      ContentType: objectType,
    };
    let result = await s3.putObject(params).promise();
    console.log(`File uploaded successfully at https:/` + bucket +   `.s3.amazonaws.com/` + objectName);
    return result;
  } catch (error) {
    console.log('error');
  }
};

async function getObjectFromS3(bucket, key){
  try {
    var s3 = new AWS.S3();
    var params = {
      Bucket : bucket,
      Key : key
    }
    let response = await s3.getObject(params).promise();
    response = JSON.parse(response.Body.toString('utf-8'))
    // response = JSON.parse(response);
    return response;
  } catch (err) {
    console.error(err)
  }
};

module.exports = {
  putObjectToS3, getObjectFromS3
}